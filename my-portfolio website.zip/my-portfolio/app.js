const emailForm = document.getElementById('emailForm');
const emailArray = [];
$(document).ready(function() {
  $('.navbar-toggler').click(function() {
    $('.navbar-collapse').slideToggle();
  });
});

emailForm.addEventListener('submit', function(event) {
  event.preventDefault(); // prevent default form submission behavior

  const emailInput = document.getElementById('exampleInputEmail1');
  const emailValue = emailInput.value;

  console.log(emailValue); // print email value to console
  emailArray.push(emailValue); // add email to array
  console.log(emailArray);
  
  window.location.href = 'signup.html';// will navigate to signup success page on submission
});